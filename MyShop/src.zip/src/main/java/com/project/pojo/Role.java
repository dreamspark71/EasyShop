package com.project.pojo;

public enum Role {

	ADMIN,
	MEMBER,
	GUEST
}
