package com.project.pojo;

public enum Status {

	PENDING,
	COMPLETED
}
