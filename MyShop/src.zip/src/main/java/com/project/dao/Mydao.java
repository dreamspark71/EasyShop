package com.project.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.project.pojo.Product;
import com.project.pojo.User;



//import com.fresh.pojo.User;

public class Mydao extends DAO{
	
	public List<Product> getProductsForHomePage()
	{
		begin();
        Query q = getSession().createQuery("from Product");
        q.setMaxResults(12);
        List<Product> products = q.list();
        commit();
        return products;
	}
	
	public Product getProductDetails(long id)
	{
		begin();
//        Query q = getSession().createQuery("from Product where ");
//        q.setMaxResults(12);
//        List<Product> products = q.list();
//        commit();

		Criteria crit= getSession().createCriteria(Product.class);
		crit.add(Restrictions.eq("productId", Long.valueOf(id)));
        return (Product) crit.uniqueResult();
        
	}
	
	public User findByUserNamePassword(String username, String password)
	{
		begin();
        Query q = getSession().createQuery("from User where userName = :username and passWord = :password");
        q.setString("username", username);
        q.setString("password", password);
        User user = (User)q.uniqueResult();
        return user;
	}
	
	

}
